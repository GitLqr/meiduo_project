本地安装：
	sudo apt-key add gpg
	sudo dpkg -i docker-ce_17.03.2~ce-0~ubuntu-xenial_amd64.deb
